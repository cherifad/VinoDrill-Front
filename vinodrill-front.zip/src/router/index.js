import { createRouter, createWebHistory } from "vue-router";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "Home",
      component: () => import("../views/HomeView.vue"),
    },
    {
      path: "/sejour",
      name: "Séjour",
      component: () => import("../views/SejourView.vue"),
    },
    {
      path: "/sejour/:id:slug",
      name: "SingleSejour",
      component: () => import("../views/SingleSejourView.vue"),
    },
    {
      path: "/connexion",
      name: "Connexion",
      component: () => import("../views/LoginView.vue"),
    },
  ],
});

export default router;
