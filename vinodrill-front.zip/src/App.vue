<script setup>
import { RouterLink, RouterView } from "vue-router";
import { onMounted, ref } from 'vue';

const height = ref(0);

onMounted(() => {
  const header = document.querySelector("header");

  // get header height
  const headerHeight = header?.clientHeight;

  height.value = headerHeight + 20;
  
  // get header height on resize
  window.addEventListener("resize", () => {
    const headerHeight = header?.clientHeight;
    height.value = headerHeight + 35;
  });
});
</script>

<template>
  <header id="header" class="flex absolute top-0 w-full justify-between z-50 px-10 pt-10">
    <div class="flex items-center gap-8">
      <RouterLink to="/">
        <span class="brandName text-4xl font-semibold"
          >Vino<span style="color: #cb7169">Drill</span></span
        >
      </RouterLink>
      <ul
        class="flex gap-4 text-2xl text-white border-l-2 border-zinc-800 pl-8"
      >
        <li>
          <RouterLink to="/sejour">Séjour</RouterLink>
        </li>
        <li>Vignoble</li>
        <li>Route des vins</li>
        <li>Coffret Cadeau</li>
        <li>Offre entreprise</li>
      </ul>
    </div>
    <div class="flex text-2xl text-white items-center gap-10">
      <span class="flex items-center gap-2">
        <img src="./assets/img/france.png" class="" alt="french flag" />
        Français
      </span>
      <RouterLink to="/connexion" class="hover:text-opacity-90">Connexion</RouterLink>
    </div>
  </header>
  <RouterView :style="{'padding-top': + height +'px'}" class="px-10" />
</template>

<style scoped>
* {
  transition: all 0.3s ease;
}

header {
  font-family: "Poppins", sans-serif;
}

header li {
  cursor: pointer;
  font-weight: 500;
}

header li:hover {
  color: #cb7169;
}

header li {
  color: #350a06;
}

.pass {
  font-family: "PassengerDisplay", sans-serif;
}

.title {
  font-size: 9rem;
  line-height: 132px;
  text-transform: capitalize;
}
</style>
