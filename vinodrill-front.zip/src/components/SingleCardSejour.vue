<template>
    <div class="flex flex-col gap-4 mb-5 hover:scale-110 transition ease-in-out">
        <img :src="image" :alt="title + 'image'" class="rounded-xl shadow-md">
        <h1 class="text-2xl font-bold">{{ title }}</h1>
        <p v-if="days" class="text-2xl flex items-center"><ion-icon name="time-outline" class="mr-2"></ion-icon>{{ days }} jour(s)<span v-if="nights > 0"> / {{ nights }} nuit(s)</span></p>
        <p v-else class="text-2xl">{{ libelleTemps }}</p>
        <p class="text-2xl">{{ price }}€ / <span class=" text-rose">Pers</span></p>
    </div>
</template>

<script setup lang="ts">
const props = defineProps<{
    title: string;
    description: string;
    nights: any;
    days: any;
    image: string;
    price: number;
    id: number;
    libelleTemps: any;
    }>(); 
</script>

<style scoped>

</style>