<template>
    <div>
        <!-- make a rating component -->
        <div class="flex flex-col gap-4 bg-white shadow-lg rounded-md text-black p-5">
            <h1 class=" font-bold text-5xl">Avis client</h1>
            <div class="flex gap-2 items-end">
                <h1 class=" font-bold text-7xl">{{ ratingaverage }}/5</h1>
                <div class="flex gap-1 items-center text-2xl">                    
                    {{ ratingcount }} avis
                </div>
            </div>
            <div class="flex items-center gap-2 text-xl" v-for="i in 5">
                <!-- rating bars -->
                {{ i }}
                <div class="flex-1 h-4 bg-gray-200 rounded-md">
                    <div class="h-4 rounded-md" :style="{ width: (ratingcountarray[i - 1] / ratingcount) * 100 + '%', backgroundColor: ratingcolorsarray[i - 1] }"></div>
                </div>
                <span>{{ ratingcountarray[i - 1] }}</span>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
// color array for the rating bars from red to green
const ratingcolorsarray = ['#ff0000', '#ff4d00', '#ff9900', '#ffff00', '#00ff00'];
const props = defineProps<{
    ratingcount: number;
    ratingcountarray: number[];
    ratingaverage: number;
    }>();
</script>   

<style scoped>

</style>