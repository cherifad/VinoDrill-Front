<template>
    <div class="flex fixed h-screen w-screen items-center justify-center">
        <div class="p-5 bg-rouge rounded-3xl shadow-xl">
            <lord-icon
                src="https://cdn.lordicon.com/xlrvqbwc.json"
                trigger="loop"
                colors="outline:#ffffff,primary:#92140c,secondary:#ebe6ef"
                stroke="55"
                style="width:250px;height:250px">
            </lord-icon>
        </div>
    </div>
</template>