<template>

</template>

<script setup lang="ts">

defineProps<{
    note: number;
    comment: string;
    date: string;
    title: string;
    }>();

</script>

<style scoped>

</style>