<template>
    <div v-if="sejour" class="min-h-screen px-32">
        <div class="">
            <div class="grid gap-4 grid-cols-4">
                <div class=" w-2/5 col-span-3 flex items-center justify-center">
                    <img :src="sejour.photosejour" :alt="sejour.titresejour + ' image'" class=" w-full h-auto rounded-lg shadow-lg">
                </div>
                <ReviewResume v-if="rating" :ratingaverage="rating" :ratingcount="ratingcount" :ratingcountarray="ratingcountarray" />
            </div>
            <h1 class="mt-12 text-5xl" id="passenger">{{ sejour.titresejour }}</h1>
        </div>
        <div>
            
        </div>
        <div class="text-2xl font-bold">
            <ion-icon name="moon-outline"></ion-icon>
            nb de nuits {{ sejour.nbnuit }}
        </div>
        <div>
            
        </div>
    </div>
    <div v-else>
        <LoadComponent />
    </div>

</template>

<script setup lang="ts">
// get url params
import { useRoute } from 'vue-router';
import { onMounted, ref } from 'vue';
import LoadComponent from '../components/LoadComponent.vue';
import axios from 'axios';
import ReviewResume from '../components/ReviewResume.vue';

const route = useRoute();
// get slug from url
const id = route.params.id;
const slug = route.params.slug;

const sejour: any = ref(null);
const ratingcount: any = ref(null);
const ratingcountarray: any = ref(null);
const rating: any = ref(null);

onMounted(async () => {
    axios.get('http://localhost:8000/api/sejour/' + id + '?avis=k')
    .then((response) => {
        sejour.value = response.data['data'];
        reviewAnalytics(response.data['data']['avis']);
        console.log(sejour.value);
    })
    .catch((error) => {
        console.log(error);
    });
});

// generate slug from title
function slugify(string: string) {
    return string
        .toString()
        .normalize('NFD') // split an accented letter in the base letter and the acent
        .replace(/[\u0300-\u036f]/g, '') // remove all previously split accents
        .toLowerCase()
        .trim()
        .replace(/&/g, '-and-') // replace & with 'and'
        .replace(/[\s\W-]+/g, '-'); // replace spaces, non-word characters and dashes with a single dash (-)
}

function reviewAnalytics(review: any) {
    ratingcount.value = review.length;
    /* get number of each rating */
    let rating1 = 0;
    let rating2 = 0;
    let rating3 = 0;
    let rating4 = 0;
    let rating5 = 0;
    let ratingaverage = 0;
    for (let i = 0; i < review.length; i++) {
        ratingaverage += review[i].note;
        switch (review[i].note) {
            case 1:
                rating1++;
                break;
            case 2:
                rating2++;
                break;
            case 3:
                rating3++;
                break;
            case 4:
                rating4++;
                break;
            case 5:
                rating5++;
                break;
        }
    }
    rating.value = ratingFormat(ratingaverage / review.length);
    ratingcountarray.value = [rating1, rating2, rating3, rating4, rating5];
    ratingcount.value = review.length;
}

function ratingFormat(x) {
    return Math.round((x + Number.EPSILON) * 10) / 10;
}
</script>

<style scoped>

</style>