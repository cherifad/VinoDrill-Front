<template>
    <div v-if="sejours && libelleDestination" class="">
        <div class="grid grid-cols-4">
            <div class=" dark:bg-gray-600 text-2xl font-bold rounded-md shadow-sm p-7 h-fit">
                Filtres
                <div>
                    <Input @filter="(i) => getFilteredData(i)" columnName="rien" :data="libelleDestination" name="Destinations" placeholder="Recherchez ici"/>
                </div>
            </div>
            <div class="col-span-3">
                <span class="pl-12">{{ sejourcount}} sejour(s) trouvé(s)</span>
                <div class="pt-12 flex gap-10 flex-wrap justify-center">
                <router-link v-for="sejour in sejours" :key="sejour.idsejour" :to="{name: 'SingleSejour', params: {id: sejour.idsejour, slug: slugify(sejour.titresejour)}}">
                    <SingleCardSejour
                        :key="sejour.idsejour"
                        :title="sejour.titresejour"
                        :description="sejour.descriptionsejour"
                        :nights="sejour.nbnuit"
                        :days="sejour.nbjour"
                        :image="sejour.photosejour"
                        :price="sejour.prixsejour"
                        :id="sejour.idsejour"
                        :libelleTemps="sejour.libelletemps"
                    />
                </router-link>
                </div>
            </div>
        </div>
    </div>
    <div v-else>
        <LoadComponent />
    </div>


</template>

<script setup lang="ts">import { onMounted, ref } from 'vue';
import SingleCardSejour from '../components/SingleCardSejour.vue';
import axios from 'axios';
import { RouterLink } from "vue-router";
import LoadComponent from '../components/LoadComponent.vue';
import Input from '../components/Filters/Input.vue';

const sejours: any = ref(null);
const sejourcount: any = ref(null);
const filteredData: any = ref(null);
const destination: any = ref(null);
const libelleDestination: any = ref(null);
const idDestination: any = ref(null);

// generate slug from title
function slugify(string: string) {
    return string
        .toString()
        .normalize('NFD') // split an accented letter in the base letter and the acent
        .replace(/[\u0300-\u036f]/g, '') // remove all previously split accents
        .toLowerCase()
        .trim()
        .replace(/&/g, '-and-') // replace & with 'and'
        .replace(/[\s\W-]+/g, '-'); // replace spaces, non-word characters and dashes with a single dash (-)
}

onMounted(async () => {
    axios.get('http://localhost:8000/api/sejour')
    .then((response) => {
        sejours.value = response.data['data'];
        sejourcount.value = response.data['data'].length;
    })
    .catch((error) => {
        console.log(error);
    });

    axios.get('http://localhost:8000/api/destination')
    .then((response) => {
        destination.value = response.data['data'];
        console.log(destination.value[0].libelledestination);
        libelleDestination.value = destination.value.map((item: any) => item.libelledestination);
    })
    .catch((error) => {
        console.log(error);
    });
});

const getFilteredData = (data: any) => {
    filteredData.value = data;

    console.log(sejours.value);

    // filter sejour with iddestination
    idDestination.value = destination.value.filter((item: any) => filteredData.value.includes(item.libelledestination));
    // get only the id
    idDestination.value = idDestination.value.map((item: any) => item.iddestination);
    console.log(idDestination.value);
    sejours.value = sejours.value.filter((item: any) => idDestination.value.includes(item.iddestination));

    console.log(sejours.value);
}

</script>

<style scoped>

</style>