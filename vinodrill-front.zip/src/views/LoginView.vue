<template>
    <div class="flex h-screen">
        <div class=" w-3/5 p-5">
            <div id="img" class="h-full w-full flex flex-col justify-end p-7 gap-5">
                <h1 class=" text-4xl font-bold">Domaine de Lagravière</h1>
                <p class=" font-normal text-2xl">Bordeaux</p>
            </div>
        </div>
        <div class="w-2/5 p-5 flex flex-col gap-10 items-center">
            <h1 id="passenger" class=" text-5xl">Bonjour !</h1>
            <div id="toggle" class="flex gap-2 relative bg-rose p-2 rounded-full">
                <div class="flex-1 text-center active p-2 text-rouge">
                    <span>Connexion</span>
                </div>
                <div class="flex-1 text-center p-2 text-rouge">
                    <span>Inscription</span>
                </div>
                <div class=" absolute">

                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>
#img {
    background-image: url("../assets/img/vineyard-ga92acf920_1920.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    border-radius: 29px;
}
#toggle {
    min-width: 330px;
}
.active {
    background-color: #350a06;
    color: white;
    border-radius: 100px;
}
</style>